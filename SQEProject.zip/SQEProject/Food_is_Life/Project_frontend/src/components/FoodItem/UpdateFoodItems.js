import React from "react";

export default function UpdateFoodItems() {
  return <div>UpdateFoodItems</div>;
}
