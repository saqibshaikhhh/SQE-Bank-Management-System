export default function Order() {
  return (
    <div>
      <h1>Order</h1>
    </div>
  );
}
